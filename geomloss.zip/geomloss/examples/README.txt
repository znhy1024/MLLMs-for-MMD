====================
Gallery of examples
====================

These self-contained examples showcase the features of the :mod:`geomloss` module.
