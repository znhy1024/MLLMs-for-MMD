.. _sinkhorn-multiscale:

The multiscale Sinkhorn algorithm
-------------------------------------

**Outperform** the baseline Auction and Sinkhorn algorithms
by a factor **x50-100** with adaptive coarse-to-fine strategies: