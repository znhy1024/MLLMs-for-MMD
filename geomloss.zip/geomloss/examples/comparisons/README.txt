Kernel vs. Hausdorff vs. Sinkhorn 
--------------------------------------

See the difference between
our **kernel**, **hausdorff** and **sinkhorn**
loss functions:
