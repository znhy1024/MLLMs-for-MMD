Optimal Transport
----------------------

Use the
**sinkhorn** loss as an affordable, drop-in replacement
for the Wasserstein distance: