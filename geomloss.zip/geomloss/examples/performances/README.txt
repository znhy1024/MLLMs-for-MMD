Performances
----------------

Select the hyper-parameters that are best suited to your data:
